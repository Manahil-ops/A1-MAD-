// App.js
import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
  Alert,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/FontAwesome';

// Dummy Data with Real Product Photos
const categories = [
  { id: 1, name: 'Electronics', icon: 'laptop' },
  { id: 2, name: 'Clothing', icon: 'tshirt' },
  { id: 3, name: 'Home & Kitchen', icon: 'home' },
  { id: 4, name: 'Sports', icon: 'futbol-o' },
];

const products = [
  {
    id: 1,
    name: 'Wireless Headphones',
    price: 99.99,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    description: 'High-quality wireless headphones with noise cancellation. Perfect for music lovers and professionals.',
    category: 'Electronics',
    reviews: [
      { id: 1, user: 'John Doe', rating: 5, comment: 'Great product!' },
      { id: 2, user: 'Jane Smith', rating: 4, comment: 'Good sound quality.' },
    ],
  },
  {
    id: 2,
    name: 'Smart Watch',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    description: 'A smartwatch with fitness tracking, heart rate monitoring, and long battery life.',
    category: 'Electronics',
    reviews: [
      { id: 1, user: 'Alice', rating: 5, comment: 'Love it!' },
      { id: 2, user: 'Bob', rating: 3, comment: 'Battery life could be better.' },
    ],
  },
  {
    id: 3,
    name: 'Laptop Backpack',
    price: 49.99,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    description: 'Durable and stylish backpack for laptops up to 15 inches. Water-resistant and ergonomic design.',
    category: 'Clothing',
    reviews: [
      { id: 1, user: 'Charlie', rating: 4, comment: 'Very comfortable.' },
      { id: 2, user: 'Diana', rating: 5, comment: 'Great value for money.' },
    ],
  },
];

// Home Screen
const HomeScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search products..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <Icon name="search" size={20} color="#888" style={styles.searchIcon} />
      </View>
      <Text style={styles.header}>Categories</Text>
      <FlatList
        data={categories}
        horizontal
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.categoryCard}
            onPress={() =>
              navigation.navigate('ProductListing', { category: item.name })
            }
          >
            <Icon name={item.icon} size={30} color="#007bff" />
            <Text style={styles.categoryName}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
      <Text style={styles.header}>Featured Products</Text>
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.productCard}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
          >
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
          </TouchableOpacity>
        )}
      />
      <TouchableOpacity
        style={styles.cartButton}
        onPress={() => navigation.navigate('Cart')}
      >
        <Icon name="shopping-cart" size={24} color="#fff" />
      </TouchableOpacity>
    </SafeAreaView>
  );
};

// Product Listing Screen
const ProductListingScreen = ({ route, navigation }) => {
  const { category } = route.params;
  const filteredProducts = products.filter(
    (product) => product.category === category
  );

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>{category}</Text>
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.productCard}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
          >
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
};

// Product Details Screen
const ProductDetailsScreen = ({ route, navigation }) => {
  const { product } = route.params;
  const [quantity, setQuantity] = useState(1);

  const addToCart = () => {
    Alert.alert('Added to Cart', `${product.name} has been added to your cart.`);
    navigation.navigate('Cart', { product, quantity });
  };

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.detailsImage} />
      <Text style={styles.detailsName}>{product.name}</Text>
      <Text style={styles.detailsPrice}>${product.price.toFixed(2)}</Text>
      <Text style={styles.detailsDescription}>{product.description}</Text>
      <Text style={styles.sectionHeader}>Reviews</Text>
      {product.reviews.map((review) => (
        <View key={review.id} style={styles.reviewCard}>
          <Text style={styles.reviewUser}>{review.user}</Text>
          <Text style={styles.reviewRating}>Rating: {review.rating}/5</Text>
          <Text style={styles.reviewComment}>{review.comment}</Text>
        </View>
      ))}
      <TextInput
        style={styles.quantityInput}
        placeholder="Quantity"
        value={quantity.toString()}
        onChangeText={(text) => setQuantity(parseInt(text) || 1)}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.button} onPress={addToCart}>
        <Text style={styles.buttonText}>Add to Cart</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// Cart Screen
const CartScreen = ({ route }) => {
  const { product, quantity } = route.params || {};
  const [cartItems, setCartItems] = useState([]);

  if (product) {
    setCartItems([...cartItems, { ...product, quantity }]);
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Your Cart</Text>
      {cartItems.length === 0 ? (
        <Text style={styles.subHeader}>No items in your cart.</Text>
      ) : (
        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.cartItem}>
              <Image source={{ uri: item.image }} style={styles.cartItemImage} />
              <View style={styles.cartItemDetails}>
                <Text style={styles.cartItemName}>{item.name}</Text>
                <Text style={styles.cartItemPrice}>${item.price.toFixed(2)}</Text>
                <Text style={styles.cartItemQuantity}>Quantity: {item.quantity}</Text>
              </View>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};

// Navigation Setup
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'MyShop' }}
        />
        <Stack.Screen
          name="ProductListing"
          component={ProductListingScreen}
          options={{ title: 'Products' }}
        />
        <Stack.Screen
          name="ProductDetails"
          component={ProductDetailsScreen}
          options={{ title: 'Product Details' }}
        />
        <Stack.Screen
          name="Cart"
          component={CartScreen}
          options={{ title: 'Your Cart' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
  },
  searchIcon: {
    marginLeft: 10,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  categoryCard: {
    alignItems: 'center',
    marginRight: 20,
  },
  categoryName: {
    marginTop: 5,
    fontSize: 14,
  },
  productCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
  },
  productImage: {
    width: '100%',
    height: 150,
    marginBottom: 10,
    borderRadius: 10,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 14,
    color: '#888',
  },
  detailsImage: {
    width: '100%',
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  detailsName: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  detailsPrice: {
    fontSize: 20,
    color: '#888',
    marginBottom: 20,
  },
  detailsDescription: {
    fontSize: 16,
    marginBottom: 20,
  },
  sectionHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  reviewCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  reviewUser: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  reviewRating: {
    fontSize: 14,
    color: '#888',
  },
  reviewComment: {
    fontSize: 14,
    marginTop: 5,
  },
  quantityInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 20,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartButton: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  cartItemImage: {
    width: 50,
    height: 50,
    borderRadius: 10,
    marginRight: 15,
  },
  cartItemDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  cartItemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartItemPrice: {
    fontSize: 14,
    color: '#888',
  },
  cartItemQuantity: {
    fontSize: 14,
    color: '#888',
  },
});

export default App;